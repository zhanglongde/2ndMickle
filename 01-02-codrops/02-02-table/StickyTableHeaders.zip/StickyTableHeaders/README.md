Sticky Table Headers &amp; Columns
=========

*A tutorial on how to create sticky headers and columns for tables using jQuery. The solution is an alternative to other sticky table header approaches and it addresses the overflowing table problem including adding support for biaxial headers.*

[Article on Codrops](http://tympanus.net/codrops/?p=18116)

[Demo](http://tympanus.net/Tutorials/StickyTableHeaders/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

[© Codrops 2013](http://www.codrops.com)


