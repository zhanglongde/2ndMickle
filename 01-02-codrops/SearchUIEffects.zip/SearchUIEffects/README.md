# Inspiration for Search UI Effects

A couple of schematic, inspirational proof-of-concepts for how to show the search interface on a website using CSS animations.

[Article on Codrops](https://tympanus.net/codrops/?p=29878)

[Demo](http://tympanus.net/Development/SearchUIEffects/)

## License

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

## Misc

Follow Codrops: [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/pages/Codrops/159107397912), [Google+](https://plus.google.com/101095823814290637419), [GitHub](https://github.com/codrops), [Pinterest](http://www.pinterest.com/codrops/)

[© Codrops 2016](http://www.codrops.com)





