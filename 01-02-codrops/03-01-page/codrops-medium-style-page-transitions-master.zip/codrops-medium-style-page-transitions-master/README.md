Medium-Style Page Transition
============================
Find the write-up [here](http://tympanus.net/codrops/2013/10/30/medium-style-page-transition/).

__Compiling Assets__

The assets in this project are compiled using Compass along with [LiveReload](http://livereload.com/). 

__License__

All work licensed under the MIT license.

__Author__

| ![twitter/brianmgonzalez](http://gravatar.com/avatar/f6363fe1d9aadb1c3f07ba7867f0e854?s=70](http://twitter.com/brianmgonzalez "Follow @brianmgonzalez on Twitter") |
|---|
| [Brian Gonzalez](http://briangonzalez.org) |
